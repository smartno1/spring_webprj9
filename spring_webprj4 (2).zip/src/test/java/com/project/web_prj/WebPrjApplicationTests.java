package com.project.web_prj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebPrjApplicationTests {

	@Test
	void contextLoads() {
	}

}
